<!--
$name = "Ali";
$age = 29;
$height = 5.8;
$gender = "M";
$subjects = array("ML", "CV", "DIP");
$married = false;
$children = null;
-->

<?php
$hello_message = "<h1>Hello World</h1>";
echo $hello_message;
?>
