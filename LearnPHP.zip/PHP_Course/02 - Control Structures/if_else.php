<?php
$a = 10;
if ($a == 10) {
  echo "Equal";
} elseif ($a >= 5) {
  echo "Greater than 5";
} else {
  echo "Not Equal";
}
